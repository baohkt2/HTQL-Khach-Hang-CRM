/*********************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 ********************************************************************************/

Settings_Vtiger_Index_Js("Settings_ITS4YouCalculateFields_Listall_Js", {
    listViewContainer: false,
    getListViewContentContainer: function () {
        if (this.listViewContentContainer == false) {
            this.listViewContentContainer = jQuery('.listViewContentDiv');
        }
        return this.listViewContentContainer;
    },
    registerNewCalculateFieldButtonEvent: function () {
        $('#newCalcField').click(function () {
            let module = app.getModuleName(),
                parent = app.getParentModuleName();

            window.location.href = "index.php?module=" + module + "&parent=" + parent + "&view=List";
        });
    },
    registerRowClickEvent: function () {
        jQuery('.listViewEntries').on('click', function (e) {
            let elem = jQuery(e.currentTarget);
            let recordUrl = elem.data('recordurl');
            if (typeof recordUrl == 'undefined') {
                return;
            }
            window.location.href = recordUrl;
        });
    },
    registerOnDeleteCalcFieldEvent: function () {
        jQuery('.deleteRecordButton').on('click', function (e) {
            let elem = jQuery(e.currentTarget),
                tabid = elem.closest('tr').data('id'),
                fieldid = elem.closest('tr').data('fieldid'),
                message = app.vtranslate('JS_DELETE_QUESTION');
            app.helper.showConfirmationBox({'message': message}).then(function () {
                let params = {
                    "type": "POST",
                    "module": app.getModuleName(),
                    "parent": "Settings",
                    "action": "DeleteAjax",
                    "tabId": tabid,
                    "fieldid": fieldid,
                    "dataType": 'json'
                };
                AppConnector.request(params).then(
                    function (data) {
                        window.location.href = data['result']['listallUrl'];
                    },
                    function (error, err) {

                    });
            });

            e.stopPropagation();
        });
    },
    registerEvents: function () {
        this._super();
        this.registerNewCalculateFieldButtonEvent();
        this.registerRowClickEvent();
        this.registerOnDeleteCalcFieldEvent();
    }
});