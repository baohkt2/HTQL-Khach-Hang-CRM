/*********************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 ********************************************************************************/

Settings_Vtiger_Index_Js("Settings_ITS4YouCalculateFields_Edit_Js", {}, {
    stepType: 'next',
    stepNum: 1,
    advanceFilterInstance: false,
    container: false,
    init: function() {
        this._super();
        this.registerOnChangeCustomFilter();
        this.registerSteps();
    },
    registerOnChangeCustomFilter: function() {
        let self = this;

        jQuery('.filtersFromList').live('change', function() {
            self.toggleCustomFilter();
        });

        jQuery('.filterConditionsDiv :input').live('change select blur', function() {
            self.saveFilter();
        });
    },
    toggleCustomFilter: function() {
        let filters = jQuery('.filterConditionsDiv'),
            customView = jQuery('[name="custom_View"]').val();

        if(parseInt(customView) >= 0) {
            filters.hide();
        } else {
            filters.show();
        }
    },
    saveFilter: function() {
        if(this.advanceFilterInstance) {
            let filterValues = this.advanceFilterInstance.getValues(),
                customView = jQuery('[name="custom_View"]').val();

            if(0 > customView) {
                jQuery('#advanced_filter').val(JSON.stringify(filterValues));
            }
        }
    },
    registerAdvancedFilter: function() {
        this.advanceFilterInstance = Vtiger_AdvanceFilter_Js.getInstance();
    },
    setStep: function(step) {
        this.stepNum = parseInt(step);
    },
    getStep: function() {
        let self = this,
            step = self.stepNum;

        if(self.stepType === 'next') {
            step++;
        } else {
            step--;
        }

        return step;
    },
    stepChanged: function() {
        let step = this.stepNum;

        if(step === 2) {
            this.toggleCustomFilter();
            if(this.stepType === 'next') {
                this.registerAdvancedFilter();
            }
        }
    },
    changeStep: function() {
        let self = this,
            step = self.getStep(),
            forms = jQuery('.workFlowContents form'),
            activeForm = jQuery('#calculateFields_step' + step);

        forms.hide();
        activeForm.show();
        self.setStep(step);

        jQuery('.step').removeClass('active')
            .filter('#Step' + step)
            .addClass('active');

        self.stepChanged();
    },
    registerSteps: function() {
        this.nextStep();
        this.backStep();
    },
    nextStep: function() {
        let self = this;

        jQuery(':submit').live('click', function(e) {
            e.preventDefault();

            let workflow = jQuery('.workFlowContents'),
                form = jQuery(this).closest('form'),
                action = form.find('[name="action"]'),
                params = form.serializeFormData(),
                step = form.find('[name="step"]').attr('value'),
                nextStep = parseInt(step) + 1,
                nextForm = jQuery('#calculateFields_step' + nextStep);

            self.stepNum = step;
            self.stepType = 'next';

            if(!action.length) {
                app.request.post({data: params}).then(function(error, data) {
                    if(!error) {
                        if(!nextForm.length) {
                            workflow.append(data);
                        } else {
                            nextForm.replaceWith(data);
                        }

                        app.changeSelectElementView(workflow);
                        self.changeStep();
                    }
                });
            } else {
                form.submit();
            }
        });
    },
    backStep: function() {
        let self = this;

        jQuery('.backStep').live('click', function() {
            let form = jQuery(this).closest('form'),
                step = form.find('[name="step"]').val();

            self.stepNum = step;
            self.stepType = 'back';
            self.changeStep();
        });
    },
});