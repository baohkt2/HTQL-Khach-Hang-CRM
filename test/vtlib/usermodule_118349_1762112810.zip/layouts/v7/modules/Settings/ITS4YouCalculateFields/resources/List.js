/*********************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 ********************************************************************************/

Settings_Vtiger_Index_Js("Settings_ITS4YouCalculateFields_List_Js", {
    listViewContentContainer: false,
    registerOnLoadChangeEvent: function () {
        let thisElement = this;
        jQuery(function () {
            let tabId = jQuery('#ModName').val(),
                translatedModuleName = jQuery('#ModName option:selected').text(),
                params = {
                    data: {
                        "module": app.getModuleName(),
                        "parent": "Settings",
                        "view": "List",
                        "tabId": tabId,
                        "translatedModuleName": translatedModuleName,
                    }
                };

            app.request.post(params).then( function (error, data) {
                if(!error) {
                    jQuery('#listViewContents').html(data);
                    thisElement.registerAddCustomFieldEvent();
                }
            });
        });
    },
    registerSelectChangeEvent: function () {
        let thisElement = this;
        jQuery('#entityMod').on('change', function () {
            let tabId = jQuery('#ModName').val();
            let translatedModuleName = jQuery('#ModName option:selected').text();
            let params = {
                    data: {
                        "module": app.getModuleName(),
                        "parent": "Settings",
                        "view": "List",
                        "tabId": tabId,
                        "translatedModuleName": translatedModuleName,
                    }
                };

            app.request.post(params).then( function (error, data) {
                if(!error) {
                    if(data) {
                        jQuery('#listViewContents').html(data);
                        thisElement.registerAddCustomFieldEvent();
                    }
                }
            });
        });
    },
    getListViewContentContainer: function () {
        if (this.listViewContentContainer === false) {
            this.listViewContentContainer = jQuery('.listViewContentDiv');
        }
        return this.listViewContentContainer;
    },
    /*
     * click on the row in table and go to record url
     */
    registerRowClickEvent: function () {
        let listViewContentDiv = this.getListViewContentContainer();
        listViewContentDiv.on('click', '.listViewEntries', function (e) {
            let elem = jQuery(e.currentTarget);
            let recordUrl = elem.data('recordurl');
            if (typeof recordUrl == 'undefined') {
                return;
            }
            window.location.href = recordUrl;
        });
    },
    /**
     * Function to register click evnet add custom field button
     */
    getCustomFieldForm: function(tabId) {
        let aDeferred = jQuery.Deferred(),
            params = {
                data: {
                    module: app.getModuleName(),
                    parent: app.getParentModuleName(),
                    view: 'AddCustomFields',
                    tabId: tabId
                }
            };

        app.request.post(params).then(function(error, data) {
            if(!error) {
                aDeferred.resolve(data);
            } else {
                aDeferred.reject(error);
            }
        });

        return aDeferred.promise();
    },
    registerAddCustomFieldEvent: function () {
        let self = this;

        jQuery('.addCustomField').click(function () {
            let tabid = jQuery('#tabid').val();

            self.getCustomFieldForm(tabid).then(function(data) {

                data = jQuery(data);

                app.helper.showModal(data);
                app.showSelect2ElementView(data.find('select'));

                let form = data.find('.createCustomFieldForm');
                form.attr('id', 'createFieldForm');

                self.customFieldSubmitControl(form, tabid);
                self.registerFieldTypeChangeEvent(form);
            });
        });
    },
    customFieldSubmitControl: function(form, tabid) {
        let self = this,
            params = {
                submitHandler: function(form) {
                    form = jQuery(form);

                    let blockId = form.find('[name="bloks"]').val();

                    self.addCustomField(tabid, blockId, form);
                }
            };
        form.vtValidate(params);
    },
    /**
     * Function to save the custom field details
     */
    addCustomField: function (tabId, blockId, form) {
        let params = form.serializeFormData();

        params['module'] = 'LayoutEditor';
        params['parent'] = 'Settings';
        params['action'] = 'Field';
        params['mode'] = 'add';
        params['blockid'] = blockId;
        params['sourceModule'] = jQuery('#selectedModuleName').val();

        AppConnector.request(params).then( function (data) {
            let message = {
                title: app.vtranslate('JS_CUSTOM_FIELD_ADDED') + ': ' + data.label,
                type: 'success',
            };

            app.helper.hideModal();
            window.location.href = "index.php?module=ITS4YouCalculateFields&parent=Settings&view=List&tabId=" + tabId;

            Vtiger_Helper_Js.showPnotify(message);
        }, function(error) {
            let message = {
                title: error.message,
                type: 'error',
            };

            Vtiger_Helper_Js.showPnotify(message);
        });
    },
    /**
     * Function to register change event for fieldType while adding custom field
     */
    registerFieldTypeChangeEvent: function (form) {
        let lengthInput = form.find('[name="fieldLength"]'),
            //special validators while adding new field
            lengthValidator = [{'name': 'DecimalMaxLength'}],
            maxLengthValidator = [{'name': 'MaxLength'}],
            decimalValidator = [{'name': 'FloatingDigits'}];

        //By default add the max length validator
        lengthInput.data('validator', maxLengthValidator);

        //register the change event for field types
        form.find('[name="fieldType"]').on('change', function (e) {
            form.find('#blocksS').removeClass('hide');
            form.find('#fieldLabel').removeClass('hide');
            form.find('[name="fieldLength"]').removeClass('hide');
            let currentTarget = jQuery(e.currentTarget),
                lengthInput = form.find('[name="fieldLength"]'),
                selectedOption = currentTarget.find('option:selected');

            //hide all the elements like length, decimal,picklist
            form.find('.supportedType').addClass('hide');

            if (selectedOption.data('lengthsupported')) {
                form.find('.lengthsupported').removeClass('hide');
                lengthInput.data('validator', maxLengthValidator);
            }

            if (selectedOption.data('decimalsupported')) {
                let decimalFieldUi = form.find('.decimalsupported'),
                    decimalInput = decimalFieldUi.find('[name="decimal"]'),
                    maxFloatingDigits = selectedOption.data('maxfloatingdigits');

                decimalFieldUi.removeClass('hide');

                if (typeof maxFloatingDigits != "undefined") {
                    decimalInput.data('validator', decimalValidator);
                    lengthInput.data('validator', lengthValidator);
                }

                if (selectedOption.data('decimalreadonly')) {
                    decimalInput.val(maxFloatingDigits).attr('readonly', true);
                } else {
                    decimalInput.removeAttr('readonly').val('');
                }
            }

            if (selectedOption.data('predefinedvalueexists')) {
                let pickListUi = form.find('.preDefinedValueExists');
                pickListUi.removeClass('hide');
            }
            if (selectedOption.data('picklistoption')) {
                let pickListOption = form.find('.picklistOption');
                pickListOption.removeClass('hide');
            }
        });
    },
    registerOnDeleteCalcFieldEvent: function () {
        let listViewContentDiv = jQuery('.listViewContentDiv');
        jQuery(listViewContentDiv).on('click', '.deleteRecordButton', function (e) {
            let elem = jQuery(e.currentTarget);
            let tabid = elem.closest('tr').data('id');
            let fieldid = elem.closest('tr').data('fieldid');
            app.helper.showConfirmationBox({'message': 'Are you sure you want to delete this CalculateField?'}).then(function () {
                let params = {
                    "type": "POST",
                    "module": app.getModuleName(),
                    "parent": "Settings",
                    "action": "DeleteAjax",
                    "tabId": tabid,
                    "fieldid": fieldid,
                    "dataType": 'json'
                };
                AppConnector.request(params).then( function (data) {
                        window.location.href = data['result']['recordUrl'];
                }, function (error, err) {

                });
            });

            e.stopPropagation();
        });
    },
    registerEvents: function () {
        let thisElement = this;
        $(document).ready(function () {
            thisElement.registerOnLoadChangeEvent();
        });
        this.registerOnDeleteCalcFieldEvent();
        this.registerSelectChangeEvent();
        this.registerRowClickEvent();
        this.registerAddCustomFieldEvent();

    }
});