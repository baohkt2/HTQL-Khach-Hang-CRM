<?php
/*********************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 ********************************************************************************/

require_once 'modules/Webforms/model/WebformsModel.php';
require_once 'include/Webservices/DescribeObject.php';

class ITS4YouCalculateFields
{

    protected static $moduleDescribeCache = array();
    public $LBL_MODULE_NAME = 'Calculate Fields';
    public $LBL_MODULE_NAME_OLD = 'Calculate Fields';
    public $db, $log;

    // Cache to speed up describe information store
    public $moduleName = 'ITS4YouCalculateFields';

    public function __construct()
    {
        global $log;

        $this->db = PearDatabase::getInstance();
        $this->log = $log;
    }

    public static function checkAdminAccess($user)
    {

    }

    public static function getModuleDescribe($module)
    {

    }

    public static function getFieldInfo($module, $fieldname)
    {

    }

    public static function getFieldInfos($module)
    {

    }

    /**
     * @throws Exception
     */
    public function vtlib_handler($moduleName, $eventType)
    {
        switch($eventType) {
            case 'module.preuninstall':
            case 'module.disabled':
                $this->updateCron(false);
            case 'module.preupdate':
                $this->deleteCustomLinks();
                break;
            case 'module.postinstall':
            case 'module.enabled':
                $this->updateCron();
            case 'module.postupdate':
                $this->addCustomLinks();
                break;
        }
    }

    /**
     * @throws Exception
     */
    public function addCustomLinks()
    {
        $this->updateEventHandler();
        $this->updateSettings();
        $this->updateTables();
    }

    public function updateTables()
    {
        $this->db->pquery('ALTER TABLE `its4you_calculatefields` CHANGE `from_field` `from_field` VARCHAR(255)');

        if (!columnExists('scheduling_type', 'its4you_calculatefields')) {
            $this->db->query('ALTER TABLE its4you_calculatefields ADD COLUMN scheduling_type VARCHAR(10) default "cron"');
        }

        if (!columnExists('bulk_save_mode', 'its4you_calculatefields')) {
            $this->db->query('ALTER TABLE its4you_calculatefields ADD COLUMN bulk_save_mode INT(1) DEFAULT NULL');
        }

        if (!columnExists('timestamp_no_change_mode', 'its4you_calculatefields')) {
            $this->db->query('ALTER TABLE its4you_calculatefields ADD COLUMN timestamp_no_change_mode INT(1) DEFAULT NULL');
        }
    }

    /**
     * @throws Exception
     */
    public function deleteCustomLinks()
    {
        $this->updateEventHandler(false);
        $this->updateSettings(false);
    }

    /**
     * @throws Exception
     */
    public function updateSettings($register = true)
    {
        $name = 'Calculate Fields';
        $this->db->pquery('DELETE FROM vtiger_settings_field WHERE name IN (?,?,?)', [$this->LBL_MODULE_NAME_OLD, $this->LBL_MODULE_NAME, $name]);

        if ($register) {
            $image = '';
            $description = 'Calculate Fields in Modules.';
            $linkTo = 'index.php?module=ITS4YouCalculateFields&parent=Settings&view=Listall';
            $fieldId = $this->db->getUniqueID('vtiger_settings_field');
            $blockId = getSettingsBlockId('LBL_OTHER_SETTINGS');
            $sequenceResult = $this->db->pquery('SELECT max(sequence) + 1 AS sequence FROM vtiger_settings_field WHERE blockid = ?', array($blockId));
            $sequence = $this->db->query_result($sequenceResult, 0, 'sequence');
            $this->db->pquery('INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence, active) VALUES (?,?,?,?,?,?,?,?)', array($fieldId, $blockId, $name, $image, $description, $linkTo, $sequence, 0));
        }
    }

    /**
     * name, handler, frequency, module, sequence, description
     */
    public $registerCron = array(
        array('ITS4YouCalculateFields', 'modules/ITS4YouCalculateFields/cron/CalculateFields.service', 86400, 'ITS4YouCalculateFields', 0, 'Recommended frequency for Calculate Fields 4 you is 1 day'),
    );

    public function updateCron($register = true)
    {
        foreach ($this->registerCron as $cronInfo) {
            list($name, $handler, $frequency, $module, $sequence, $description) = $cronInfo;

            Vtiger_Cron::deregister($name);

            if ($register) {
                Vtiger_Cron::register($name, $handler, $frequency, $module, 1, $sequence, $description);
            }
        }
    }

    /**
     * [events, file, class, condition, dependOn, modules]
     */
    public $registerEventHandler = [
        ['vtiger.entity.aftersave', 'modules/ITS4YouCalculateFields/handlers/CalculateFieldsHandler.php', 'CalculateFieldsHandler'],
    ];

    /**
     * @param bool $register
     */
    public function updateEventHandler($register = true)
    {
        $eventsManager = new VTEventsManager($this->db);

        foreach ($this->registerEventHandler as $data) {
            list($events, $fileName, $className, $condition, $dependOn, $modules) = $data;

            $eventsManager->unregisterHandler($className);

            if ($register) {
                $dependOn = !empty($dependOn) ? $dependOn : '[]';
                $condition = !empty($condition) ? $condition : '';

                foreach ((array)$events as $event) {
                    $eventsManager->registerHandler($event, $fileName, $className, $condition, $dependOn);

                    foreach ((array)$modules as $module) {
                        $eventsManager->setModuleForHandler($module, $className);
                    }
                }
            }
        }
    }
}