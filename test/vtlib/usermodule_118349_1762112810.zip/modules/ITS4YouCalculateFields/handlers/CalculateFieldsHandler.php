<?php

/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/

class CalculateFieldsHandler extends VTEventHandler
{
    /**
     * @param string $eventName
     * @param object $entityData
     * @throws Exception
     */
    function handleEvent($eventName, $entityData)
    {
        $moduleName = $entityData->getModuleName();

        if ('vtiger.entity.aftersave' === $eventName && !in_array($moduleName, ['Users', 'Home', 'Emails', 'Webmails'])) {
            $moduleName = 'Events' === $moduleName ? 'Calendar' : $moduleName;

            self::handleCalculate($entityData, $moduleName);
        }
    }

    /**
     * @param $entityData
     * @param $moduleName
     * @throws Exception
     */
    private static function handleCalculate($entityData, $moduleName)
    {
        $model = new ITS4YouCalculateFields_CalculateFields_Model();
        $model->schedulingType = 'aftersave';
        $model->schedulingModule = $moduleName;
        $model->setVTEntityData($entityData);
        $model->process();
    }

}

