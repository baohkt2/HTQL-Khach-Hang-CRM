<?php

/* * *******************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

require_once 'modules/com_vtiger_workflow/include.inc';
require_once 'modules/com_vtiger_workflow/expression_engine/VTExpressionsManager.inc';

class Settings_ITS4YouCalculateFields_Record_Model extends Settings_Vtiger_Record_Model
{

    /**
     * @var EnhancedQueryGenerator|QueryGenerator
     */
    public $queryGenerator;

    /**
     * @throws Exception
     */
    public static function getInstanceById($calculatefieldsid)
    {

        $adb = PearDatabase::getInstance();

        $sql = "SELECT * FROM its4you_calculatefields WHERE calculatefields_id = ?";
        $result = $adb->pquery($sql, array($calculatefieldsid));

        if ($adb->num_rows($result)) {
            $data = $adb->raw_query_result_rowdata($result, 0);
            return self::getInstanceObject($data);
        } else {
            return null;
        }
    }

    /**
     * @param array $data
     * @return Settings_ITS4YouCalculateFields_Record_Model
     */
    public static function getInstanceObject($data)
    {
        $self = new self();
        $self->setData($data);
        $self->set('conditions', Zend_Json::decode(decode_html($data['conditions'])));
        $self->setModule(Vtiger_Functions::getModuleName($data['for_module']));

        return $self;
    }

    public function setModule($moduleName)
    {
        $this->module = Vtiger_Module_Model::getInstance($moduleName);
        return $this;
    }

    public static function getInstanceByTabIdAndFieldId($tabid, $fieldid)
    {

        $adb = PearDatabase::getInstance();

        $tabname = getTabModuleName($tabid);

        $sql = "SELECT * FROM its4you_calculatefields INNER JOIN vtiger_field ON vtiger_field.fieldname = its4you_calculatefields.for_field WHERE  for_module = ? AND vtiger_field.fieldid = ?";
        $result = $adb->pquery($sql, array($tabname, $fieldid));

        if ($adb->num_rows($result)) {
            $data = $adb->raw_query_result_rowdata($result, 0);
            return self::getInstanceObject($data);
        } else {
            return null;
        }
    }

    public static function getInstanceByFromTabIdAndFromFieldId($tabid, $fieldid)
    {
        $adb = PearDatabase::getInstance();

        $tabname = getTabModuleName($tabid);

        $sql = "SELECT * FROM its4you_calculatefields INNER JOIN vtiger_field ON vtiger_field.fieldname = its4you_calculatefields.from_field WHERE  from_module = ? AND vtiger_field.fieldid = ?";
        $result = $adb->pquery($sql, array($tabname, $fieldid));

        if ($adb->num_rows($result)) {
            $data = $adb->raw_query_result_rowdata($result, 0);
            return self::getInstanceObject($data);
        } else {
            return null;
        }
    }

    public static function getCleanInstance($moduleName)
    {
        $adb = PearDatabase::getInstance();
        $data = array("for_module" => $moduleName);
        return self::getInstanceObject($data);
    }

    public function getName()
    {
        return $this->get('');
    }

    public function get($key)
    {
        return parent::get($key);
    }

    public function getModule()
    {
        return $this->module;
    }

    public function isDefault()
    {
        return true;
    }

    public function save()
    {
        $adb = PearDatabase::getInstance();
        $recordId = $this->get('calculatefields_id');
        $params = [
            'for_desc' => $this->get('for_desc'),
            'for_module' => getTabModuleName($this->get('for_module')),
            'for_field' => $this->getFieldName($this->get('for_field')),
            'from_module' => getTabModuleName($this->get('from_module')),
            'from_field' => $this->getFieldName($this->get('from_field')),
            'from_cvid' => $this->get('from_cvid'),
            'conditions' => Zend_Json::encode($this->get('conditions')),
            'operation' => $this->get('operation'),
            'scheduling_type' => $this->get('scheduling_type'),
            'timestamp_no_change_mode' => $this->get('timestamp_no_change_mode'),
            'bulk_save_mode' => $this->get('bulk_save_mode'),
        ];

        if (!empty($recordId)) {
            $sql = sprintf('UPDATE its4you_calculatefields SET %s=? WHERE calculatefields_id = ?', implode('=?,', array_keys($params)));
            $params['calculatefields_id'] = $recordId;
        } else {
            $params['calculatefields_id'] = $recordId = $adb->getUniqueID('its4you_calculatefields');
            $sql = sprintf('INSERT INTO its4you_calculatefields (%s) VALUES (%s)', implode(',', array_keys($params)), generateQuestionMarks($params));
        }

        $adb->pquery($sql, $params);
        $this->set('calculatefields_id', $recordId);
    }

    public function getFieldName($fieldid)
    {
        $adb = PearDatabase::getInstance();

        $sql = "SELECT fieldname FROM vtiger_field WHERE fieldid = ?";
        $result = $adb->pquery($sql, array($fieldid));
        $columnname = $adb->query_result($result, 0, "fieldname");

        return $columnname;
    }

    public function delete($tabid, $fieldid)
    {
        $adb = PearDatabase::getInstance();

        $tabname = getTabModuleName($tabid);
        $fieldname = $this->getFieldName($fieldid);
        $sql = "DELETE FROM its4you_calculatefields WHERE for_module = ? AND for_field = ?";
        $adb->pquery($sql, array($tabname, $fieldname));
    }

    public function getEntityMethods()
    {
        $db = PearDatabase::getInstance();
        $emm = new VTEntityMethodManager($db);
        $methodNames = $emm->methodsForModule($this->get('module_name'));
        return $methodNames;
    }

    public function getRecordLinks()
    {

        $links = array();

        $recordLinks = array(
            array(
                'linktype' => 'LISTVIEWRECORD',
                'linklabel' => 'LBL_EDIT_RECORD',
                'linkurl' => $this->getEditViewUrl(),
                'linkicon' => 'icon-pencil'
            ),
            array(
                'linktype' => 'LISTVIEWRECORD',
                'linklabel' => 'LBL_DELETE_RECORD',
                'linkurl' => 'javascript:Vtiger_List_Js.deleteRecord(' . $this->getId() . ');',
                'linkicon' => 'icon-trash'
            )
        );
        foreach ($recordLinks as $recordLink) {
            $links[] = Vtiger_Link_Model::getInstanceFromValues($recordLink);
        }

        return $links;
    }

    public function getEditViewUrl()
    {
        return '';
    }

    public function getId()
    {
        return $this->get('calculatefields_id');
    }

    /*
     *  Function used to tranform the standard filter as like as advanced filter format
     * 	@returns array of tranformed standard filter
     */

    /**
     * Function used to transform the older filter condition to suit newer filters.
     * The newer filters have only two groups one with ALL(AND) condition between each
     * filter and other with ANY(OR) condition, this functions tranforms the older
     * filter with 'AND' condition between filters of a group and will be placed under
     * match ALL conditions group and the rest of it will be placed under match Any group.
     * @return <Array>
     */
    public function transformToNewAdvancedFilter()
    {
        $standardFilter = $this->transformStandardFilter();
        $advancedFilter = $this->getAdvancedCriteria();
        $allGroupColumns = $anyGroupColumns = array();
        foreach ($advancedFilter as $index => $group) {
            $columns = $group['columns'];
            $and = $or = 0;
            $block = $group['condition'];
            if (count($columns) != 1) {
                foreach ($columns as $column) {
                    if ($column['column_condition'] == 'and') {
                        ++$and;
                    } else {
                        ++$or;
                    }
                }
                if ($and == count($columns) - 1 && count($columns) != 1) {
                    $allGroupColumns = array_merge($allGroupColumns, $group['columns']);
                } else {
                    $anyGroupColumns = array_merge($anyGroupColumns, $group['columns']);
                }
            } else {
                if ($block == 'and' || $index == 1) {
                    $allGroupColumns = array_merge($allGroupColumns, $group['columns']);
                } else {
                    $anyGroupColumns = array_merge($anyGroupColumns, $group['columns']);
                }
            }
        }
        if ($standardFilter) {
            $allGroupColumns = array_merge($allGroupColumns, $standardFilter);
        }
        $transformedAdvancedCondition = array();
        $transformedAdvancedCondition[1] = array('columns' => $allGroupColumns, 'condition' => 'and');
        $transformedAdvancedCondition[2] = array('columns' => $anyGroupColumns, 'condition' => '');

        return $transformedAdvancedCondition;
    }

    public function transformStandardFilter()
    {
        $standardFilter = $this->getStandardCriteria();
        if (!empty($standardFilter)) {
            $tranformedStandardFilter = array();
            $tranformedStandardFilter['comparator'] = 'bw';

            $fields = explode(':', $standardFilter['columnname']);

            if ($fields[1] == 'createdtime' || $fields[1] == 'modifiedtime' || ($fields[0] == 'vtiger_activity' && $fields[1] == 'date_start')) {
                $tranformedStandardFilter['columnname'] = $standardFilter['columnname'] . ':DT';
                $date[] = $standardFilter['startdate'] . ' 00:00:00';
                $date[] = $standardFilter['enddate'] . ' 00:00:00';
                $tranformedStandardFilter['value'] = implode(',', $date);
            } else {
                $tranformedStandardFilter['columnname'] = $standardFilter['columnname'] . ':D';
                $tranformedStandardFilter['value'] = $standardFilter['startdate'] . ',' . $standardFilter['enddate'];
            }
            return array($tranformedStandardFilter);
        } else {
            return false;
        }
    }

    /**
     * Function to get the list of advanced filter conditions for the current custom view
     * @return <Array> - All the advanced filter conditions for the custom view, grouped by the condition grouping
     */
    public function getAdvancedCriteria()
    {
        $db = PearDatabase::getInstance();
        $default_charset = vglobal('default_charset');

        $calculatefields_id = $this->getId();
        $advft_criteria = array();
        if (empty($calculatefields_id)) {
            return $advft_criteria;
        }

        $sql = 'SELECT * FROM vtiger_cvadvfilter_grouping WHERE cvid = ? ORDER BY groupid';
        $groupsresult = $db->pquery($sql, array($this->getId()));

        $i = 1;
        $j = 0;
        while ($relcriteriagroup = $db->fetch_array($groupsresult)) {
            $groupId = $relcriteriagroup["groupid"];
            $groupCondition = $relcriteriagroup["group_condition"];

            $ssql = 'select vtiger_cvadvfilter.* from vtiger_customview
						inner join vtiger_cvadvfilter on vtiger_cvadvfilter.cvid = vtiger_customview.cvid
						left join vtiger_cvadvfilter_grouping on vtiger_cvadvfilter.cvid = vtiger_cvadvfilter_grouping.cvid
								and vtiger_cvadvfilter.groupid = vtiger_cvadvfilter_grouping.groupid';
            $ssql .= " where vtiger_customview.cvid = ? AND vtiger_cvadvfilter.groupid = ? order by vtiger_cvadvfilter.columnindex";

            $result = $db->pquery($ssql, array($this->getId(), $groupId));
            $noOfColumns = $db->num_rows($result);
            if ($noOfColumns <= 0) {
                continue;
            }

            while ($relcriteriarow = $db->fetch_array($result)) {
                $criteria = array();
                $criteria['columnname'] = html_entity_decode($relcriteriarow["columnname"], ENT_QUOTES, $default_charset);
                $criteria['comparator'] = $relcriteriarow["comparator"];
                $advfilterval = html_entity_decode($relcriteriarow["value"], ENT_QUOTES, $default_charset);
                $col = explode(":", $relcriteriarow["columnname"]);
                $temp_val = explode(",", $relcriteriarow["value"]);
                if ($col[4] == 'D' || ($col[4] == 'T' && $col[1] != 'time_start' && $col[1] != 'time_end') || ($col[4] == 'DT')) {
                    $val = array();
                    for ($x = 0; $x < count($temp_val); $x++) {
                        if ($col[4] == 'D') {
                            /** while inserting in db for due_date it was taking date and time values also as it is
                             * date time field. We only need to take date from that value
                             */
                            if ($col[0] == 'vtiger_activity' && $col[1] == 'due_date') {
                                $originalValue = $temp_val[$x];
                                $dateTime = explode(' ', $originalValue);
                                $temp_val[$x] = $dateTime[0];
                            }
                            $date = new DateTimeField(trim($temp_val[$x]));
                            $val[$x] = $date->getDisplayDate();
                        } elseif ($col[4] == 'DT') {
                            $comparator = array('e', 'n', 'b', 'a');
                            if (in_array($criteria['comparator'], $comparator)) {
                                $originalValue = $temp_val[$x];
                                $dateTime = explode(' ', $originalValue);
                                $temp_val[$x] = $dateTime[0];
                            }
                            $date = new DateTimeField(trim($temp_val[$x]));
                            $val[$x] = $date->getDisplayDateTimeValue();
                        } else {
                            $date = new DateTimeField(trim($temp_val[$x]));
                            $val[$x] = $date->getDisplayTime();
                        }
                    }
                    $advfilterval = implode(",", $val);
                }
                $criteria['value'] = Vtiger_Util_Helper::toSafeHTML(decode_html($advfilterval));
                $criteria['column_condition'] = $relcriteriarow["column_condition"];

                $groupId = $relcriteriarow['groupid'];
                $advft_criteria[$groupId]['columns'][$j] = $criteria;
                $advft_criteria[$groupId]['condition'] = $groupCondition;
                $j++;
            }
            if (!empty($advft_criteria[$groupId]['columns'][$j - 1]['column_condition'])) {
                $advft_criteria[$groupId]['columns'][$j - 1]['column_condition'] = '';
            }
            $i++;
        }
        // Clear the condition (and/or) for last group, if any.
        if (!empty($advft_criteria[$i - 1]['condition'])) {
            $advft_criteria[$i - 1]['condition'] = '';
        }
        return $advft_criteria;
    }

    public static function getFieldId($tabid, $fieldname)
    {
        $adb = PearDatabase::getInstance();

        $sql = "SELECT fieldid FROM vtiger_field WHERE tabid=? AND fieldname=?";
        $result = $adb->pquery($sql, array($tabid, $fieldname));
        $fieldid = $adb->query_result($result, 0, 'fieldid');

        return $fieldid;
    }

    public static function getFieldLabel($tabid, $fieldname)
    {
        $adb = PearDatabase::getInstance();

        $sql = "SELECT fieldlabel FROM vtiger_field WHERE tabid = ? AND fieldname = ?";
        $result = $adb->pquery($sql, array($tabid, $fieldname));
        $fieldlabel = $adb->query_result($result, 0, 'fieldlabel');

        return $fieldlabel;
    }

    /**
     * @param int $tabId
     * @param string $fieldName
     * @return false|int|mixed|string|string[]|null
     */
    public static function getExtendedFieldLabel($tabId, $fieldName)
    {
        $label = self::getFieldLabel($tabId, $fieldName);

        if (empty($label)) {
            $label = vtranslate('LBL_RECORD_ID', 'ITS4YouCalculateFields');
        }

        return $label;
    }

    /**
     * @return array
     */
    public function getConditions()
    {
        $conditions = $this->get('conditions');

        if (is_string($conditions)) {
            Zend_Json::decode(decode_html($conditions));
        }

        if (0 === count($conditions[2]['columns'])) {
            $conditions[1]['condition'] = '';
            unset($conditions[2]);
        }

        return $conditions;
    }

    public function getForUserFocus()
    {
        $userId = $this->get('userid');

        if (empty($userId)) {
            $userId = Users::getActiveAdminId();
        }

        $focus = CRMEntity::getInstance('Users');
        $focus->id = $userId;
        $focus->retrieveCurrentUserInfoFromFile($userId);

        return $focus;
    }
}
