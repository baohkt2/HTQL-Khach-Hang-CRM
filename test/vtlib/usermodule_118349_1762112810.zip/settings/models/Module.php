<?php

/* * *******************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

require_once 'modules/com_vtiger_workflow/include.inc';
require_once 'modules/com_vtiger_workflow/expression_engine/VTExpressionsManager.inc';

class Settings_ITS4YouCalculateFields_Module_Model extends Settings_Vtiger_Module_Model
{

    public static $metaVariables = array(
        'Current Date' => '(general : (__VtigerMeta__) date) ($_DATE_FORMAT_)',
        'Current Time' => '(general : (__VtigerMeta__) time)',
        'System Timezone' => '(general : (__VtigerMeta__) dbtimezone)',
        'User Timezone' => '(general : (__VtigerMeta__) usertimezone)',
        'CRM Detail View URL' => '(general : (__VtigerMeta__) crmdetailviewurl)',
        'Portal Detail View URL' => '(general : (__VtigerMeta__) portaldetailviewurl)',
        'Site Url' => '(general : (__VtigerMeta__) siteurl)',
        'Portal Url' => '(general : (__VtigerMeta__) portalurl)',
        'Record Id' => '(general : (__VtigerMeta__) recordId)',
        'LBL_HELPDESK_SUPPORT_NAME' => '(general : (__VtigerMeta__) supportName)',
        'LBL_HELPDESK_SUPPORT_EMAILID' => '(general : (__VtigerMeta__) supportEmailid)',
    );
    public $baseTable = '';
    public $baseIndex = 'id';
    public $listFields = array();
    public $name = 'ITS4YouCalculateFields';

    public function __construct()
    {
        $this->db = PearDatabase::getInstance();
    }

    /**
     * Function to get the url for default view of the module
     * @return <string> - url
     */
    public static function getDefaultUrl()
    {
        return 'index.php?module=ITS4YouCalculateFields&parent=Settings&view=List';
    }

    /**
     * Function to get the url for create view of the module
     * @return <string> - url
     */
    public static function getCreateViewUrl()
    {
        return "javascript:Settings_ITS4YouCalculateFields_List_Js.triggerCreate('index.php?module=ITS4YouCalculateFields&parent=Settings&view=Edit')";
    }

    public static function getCreateRecordUrl()
    {
        return 'index.php?module=ITS4YouCalculateFields&parent=Settings&view=Edit';
    }

    public static function getSupportedModules()
    {
        $moduleModels = Vtiger_Module_Model::getAll(array(0, 2));
        $supportedModuleModels = array();
        foreach ($moduleModels as $tabId => $moduleModel) {
            if ($moduleModel->isEntityModule() && $moduleModel->getName() != 'Webmails') {
                $supportedModuleModels[$tabId] = $moduleModel;
            }
        }
        return $supportedModuleModels;
    }

    public static function getExpressions()
    {
        $db = PearDatabase::getInstance();

        $mem = new VTExpressionsManager($db);
        return $mem->expressionFunctions();
    }

    public static function getMetaVariables()
    {
        return self::$metaVariables;
    }

    public function getListFields()
    {
        if (!$this->listFieldModels) {
            $fields = $this->listFields;
            $fieldObjects = array();
            foreach ($fields as $fieldName => $fieldLabel) {
                if ($fieldName == 'module_name' || $fieldName == 'execution_condition') {
                    $fieldObjects[$fieldName] = new Vtiger_Base_Model(array('name' => $fieldName, 'label' => $fieldLabel, 'sort' => false));
                } else {
                    $fieldObjects[$fieldName] = new Vtiger_Base_Model(array('name' => $fieldName, 'label' => $fieldLabel));
                }
            }
            $this->listFieldModels = $fieldObjects;
        }
        return $this->listFieldModels;
    }

    public function getListViewLinks($linkParams)
    {

        $currentUserModel = Users_Record_Model::getCurrentUserModel();

        if ($currentUserModel->isAdminUser()) {
            $moduleName = $this->getName();
            $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
            $SettingsLinks = $moduleModel->getSettingLinks();

            foreach ($SettingsLinks as $link) {
                $s_parr = array(
                    'linktype' => 'LISTVIEWSETTING',
                    'linklabel' => $link["linklabel"],
                    'linkurl' => $link["linkurl"],
                    'linkicon' => ''
                );

                $links['LISTVIEWSETTING'][] = Vtiger_Link_Model::getInstanceFromValues($s_parr);
            }
        }
        return $links;
    }


    public function controlIfIsSchedulerActive()
    {

        $is_active = "0";

        $last_day = strtotime('-1 day');
        $sql = "SELECT * FROM vtiger_cron_task WHERE laststart > ?";
        $result = $this->db->pquery($sql, array($last_day));

        if ($this->db->num_rows($result) > 0) {
            $is_active = "1";
        }

        return $is_active;
    }

    public function controlIfIsCronActive()
    {

        $is_active = "0";

        $sql = "SELECT status FROM vtiger_cron_task WHERE name = ? AND module = ?";
        $result = $this->db->pquery($sql, array("ITS4YouCalculateFields", "ITS4YouCalculateFields"));

        if ($this->db->num_rows($result) > 0) {
            $status = $this->db->query_result($result, 0, "status");
            if ($status == "1") {
                $is_active = "1";
            }
        }

        return $is_active;
    }

    public function getSteps($qualifiedModule)
    {
        $steps = array(
            1 => array(
                'name' => 'Step1',
                'label' => vtranslate('LBL_MODULES', $qualifiedModule),
            ),
            2 => array(
                'name' => 'Step2',
                'label' => vtranslate('LBL_FILTER', $qualifiedModule),
            ),
            3 => array(
                'name' => 'Step3',
                'label' => vtranslate('LBL_OPERATION', $qualifiedModule),
            ),
        );

        return $steps;
    }
}
