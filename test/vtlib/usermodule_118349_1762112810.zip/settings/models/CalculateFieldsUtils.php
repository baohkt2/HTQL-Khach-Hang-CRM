<?php

/* * *******************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

function getCalculateFieldsSql()
{
    return 'SELECT DISTINCT vtiger_field.tabid, vtiger_field.fieldid, vtiger_field.fieldname, vtiger_field.fieldlabel, name, uitype FROM vtiger_field INNER JOIN vtiger_tab ON vtiger_field.tabid=vtiger_tab.tabid WHERE (vtiger_field.uitype IN (5,6,23,7,9,71,72) OR typeofdata LIKE "N%") ';
}

function getCalculateFieldsViewSupportedModules()
{

    $adb = PearDatabase::getInstance();
    $sql = getCalculateFieldsSql() . " AND vtiger_tab.name NOT IN ('Emails','Webmails','ModComments','PBXManager','SMSNotifier') AND vtiger_tab.isentitytype=?";
    $result = $adb->pquery($sql, array(1));
    $moduleList = array();

    while ($row = $adb->fetch_array($result)) {
        $moduleList[$row['tabid']] = $row['name'];
    }
    return $moduleList;
}

function getCalculateFields($tabid, $type = 'number')
{
    $adb = PearDatabase::getInstance();
    $sql = getCalculateFieldsSql() . ' AND vtiger_field.tabid != 29 AND vtiger_field.tabid =? ORDER BY vtiger_field.tabid ASC';
    $result = $adb->pquery($sql, array($tabid));

    if ($result && $adb->num_rows($result) > 0) {
        $retval = array();
        $numrows = $adb->num_rows($result);
        for ($i = 0; $i < $numrows; $i++) {
            $row = $adb->query_result_rowdata($result, $i);
            $fieldname = $row['fieldname'];

            if ('9' == $tabid && 'eventstatus' === $fieldname) {
                continue;
            }

            $uitype = $row['uitype'];
            $fieldlabel = $row['fieldlabel'];
            $retval[$row['fieldid']] = array(
                'fieldname' => $fieldname,
                'fieldlabel' => vtranslate($fieldlabel, $row['name']),
                'uitype' => $uitype,
            );
        }
        return $retval;
    } else {
        return null;
    }
}

/**
 * @param int $tabid
 * @param string $type
 * @return array|null
 */
function getExtendedCalculateFields($tabid, $type = 'number') {
    $fields = getCalculateFields($tabid, $type);

    if(is_array($fields)) {
        $fields[0] = array(
            'fieldname' => 'record_id',
            'fieldlabel' => vtranslate('LBL_RECORD_ID', 'ITS4YouCalculateFields'),
            'uitype' => 7,
        );
    }

    return $fields;
}

function getAddSupportedFieldTypes()
{
    return array(
        'Decimal',
        'Integer',
        'Percent',
        'Currency',
        'Date'
    );
}
