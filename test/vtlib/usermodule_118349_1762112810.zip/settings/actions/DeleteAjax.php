<?php

/* * *******************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Settings_ITS4YouCalculateFields_DeleteAjax_Action extends Settings_Vtiger_Basic_Action
{

    public function process(Vtiger_Request $request)
    {
        $response = new Vtiger_Response();

        $tabid = $request->get('tabId');
        $fieldid = $request->get('fieldid');

        $instance = Settings_ITS4YouCalculateFields_Record_Model::getInstanceByTabIdAndFieldId($tabid, $fieldid);

        $instance->delete($tabid, $fieldid);

        $responseData = array(
            'success' => 'true',
            'tabid' => $tabid,
            'fieldid' => $fieldid,
            'recordUrl' => "index.php?module=ITS4YouCalculateFields&parent=Settings&view=List&tabid=$tabid",
            'listallUrl' => "index.php?module=ITS4YouCalculateFields&parent=Settings&view=Listall"
        );
        $response->setResult($responseData);
        $response->emit();
    }

}
