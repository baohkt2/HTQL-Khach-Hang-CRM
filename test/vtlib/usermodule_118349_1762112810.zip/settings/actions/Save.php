<?php

/* * *******************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Settings_ITS4YouCalculateFields_Save_Action extends Settings_Vtiger_Basic_Action
{

    public function process(Vtiger_Request $request)
    {
        $for_module = $request->get('for_module');

        $instance = Settings_ITS4YouCalculateFields_Record_Model::getCleanInstance($for_module);
        $instance->set('for_desc', $request->get("description"));
        $instance->set('for_module', $request->get('for_module'));
        $instance->set('for_field', $request->get('for_field'));
        $instance->set('from_module', $request->get('from_module'));
        $instance->set('from_field', $request->get('column'));
        $instance->set('from_cvid', $request->get('cvid'));
        $instance->set('conditions', $request->get('conditions'));
        $instance->set('operation', $request->get('operation'));
        $instance->set('scheduling_type', $request->get('scheduling_type'));
        $instance->set('bulk_save_mode', $request->get('bulk_save_mode'));
        $instance->set('timestamp_no_change_mode', $request->get('timestamp_no_change_mode'));
        $instance->set('calculatefields_id', $request->get('calculatefields_id'));
        $instance->save();

        header('Location: index.php?module=ITS4YouCalculateFields&parent=Settings&view=Listall');
    }

}
