<?php

/* * *******************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */


require_once 'modules/Settings/ITS4YouCalculateFields/models/CalculateFieldsUtils.php';
require_once 'modules/Settings/ITS4YouCalculateFields/models/Record.php';

class Settings_ITS4YouCalculateFields_Debug_View extends Settings_Vtiger_Index_View
{

    public function process(Vtiger_Request $request)
    {
        $viewer = $this->getViewer($request);
        $adb = PearDatabase::getInstance();
        $adb->setDebug(true);

        error_reporting(63);
        ini_set("display_errors", 1);

        require_once 'modules/ITS4YouCalculateFields/cron/CalculateFields.service';

        $adb->setDebug(false);
    }
}
