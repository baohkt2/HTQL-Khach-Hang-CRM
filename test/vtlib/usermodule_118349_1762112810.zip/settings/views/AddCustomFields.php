<?php
/* * *******************************************************************************
 * The content of this file is subject to the Calculate Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

require_once 'modules/Settings/ITS4YouCalculateFields/models/CalculateFieldsUtils.php';

class Settings_ITS4YouCalculateFields_AddCustomFields_View extends Settings_Vtiger_IndexAjax_View
{

    public function process(Vtiger_Request $request)
    {
        $viewer = $this->getViewer($request);
        $qualified_module = $request->getModule(false);

        $tabId = $request->get('tabId');

        $isEmpty = 0;
        if (!empty($tabId) && $tabId != -1) {
            $sourceModule = getTabModuleName($tabId);
            $moduleModel = Settings_LayoutEditor_Module_Model::getInstanceByName(getTabModuleName($tabId));
            $BlockModels = $moduleModel->getBlocks();

            $viewer->assign('TABID', $tabId);
            $viewer->assign('SELECTED_MODULE_NAME', $sourceModule);
            $viewer->assign('BLOCKS', $BlockModels);
            $viewer->assign('ADD_SUPPORTED_FIELD_TYPES', getAddSupportedFieldTypes());
            $viewer->assign('FIELD_TYPE_INFO', $moduleModel->getAddFieldTypeInfo());
            $viewer->assign('ISEMPTY', $isEmpty);
        }

        $viewer->assign('QUALIFIED_MODULE', $qualified_module);

        $viewer->view('AddCustomFields.tpl', $qualified_module);
    }
}
