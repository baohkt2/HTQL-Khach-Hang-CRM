<?php
/* *********************************************************************************
 * The content of this file is subject to the ITS4YouClearCampaigns license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ******************************************************************************* */

$languageStrings = array(
	'LBL_LICENSE_USED_BY_OTHER_USERS' => 'Licencia používaná inými používateľmi', 
	'ITS4YouClearCampaign' => 'Mazanie kampane', 
	'SINGLE_ITS4YouClearCampaign' => 'Mazanie kampane', 
	'GDPRConsent' => 'Mazanie kampane', 
	'LBL_GDPRCONSENT_NAME' => 'Názov', 
	'LBL_TARGET_MODULE' => 'Modul', 
	'LBL_GDPRCONSENT_CONDITION' => 'Podmienky', 
	'LBL_NO_DISPLAY_CONDITIONS_DEFINED' => 'Podmienky zobrazenia neboli definované', 
	'LBL_GDPRS' => 'Mazanie kampane', 
	'LBL_GDPRS_SEARCH' => 'Hľadať Mazanie kampane', 
	'LBL_EXPRESSION' => 'Výraz', 
	'LBL_FIELD_NAME' => 'Pole', 
	'LBL_SET_VALUE' => 'Nastaviť hodnotu', 
	'LBL_USE_FIELD' => 'Použiť pole', 
	'LBL_USE_FUNCTION' => 'Použiť funkciu', 
	'LBL_RAW_TEXT' => 'Surový text', 
	'LBL_PF_LIST' => 'Mazanie kampane', 
	'LBL_RELATED_PF_LIST' => 'Súvisiace Mazanie kampane', 
	'LBL_ADD_RELATED_PF' => 'Pridať súvisiace Mazanie kampane', 
	'LBL_NO_RELATED_PF_FOUND' => 'Neboli nájdené žiadne súvisiace Mazanie kampane', 
	'COPYRIGHT' => ':: IT-Solutions4You', 
	'LBL_UPGRADE' => 'Aktualizácia', 
	'LBL_UNINSTALL' => 'Odinštalovať', 
	'LBL_UNINSTALL_DESC' => 'Úplne odstrániť modul z vášho Vtigera.', 
	'LBL_EXAMPLE_FIELD_NAME' => 'Pole', 
	'LBL_NOTIFY_OWNER' => 'notify_owner', 
	'LBL_ANNUAL_REVENUE' => 'annual_revenue', 
	'LBL_EXAMPLE_EXPRESSION' => 'Výraz', 
	'LBL_EXPRESSION_EXAMPLE2' => "if mailingcountry == 'India' then concat(firstname,' ',lastname) else concat(lastname,' ',firstname) end", 
	'LBL_ADD_RECORD' => 'Pridať Mazanie kampane', 
	'LBL_IF_YES_ACTIONS' => 'Ak sú podmienky splnené', 
	'LBL_IF_NO_ACTIONS' => 'Ak podmienky nie sú splnené', 
	'LBL_IF_YES_PF' => 'Ak sú podmienky splnené', 
	'LBL_IF_NO_PF' => 'Ak podmienky nie sú splnené', 
	'ITS4YouClearCampaigns' => 'Mazanie kampaní', 
	'SINGLE_ITS4YouClearCampaigns' => 'Mazanie kampaní', 
	'LBL_MODULE_NAME' => 'Mazanie kampaní', 
	'LBL_MODULE' => 'Modul', 
	'LBL_LICENSE_SETTINGS_INFO' => 'Spravujte svoj licenčný kľúč modulu', 
	'LBL_LICENSE' => 'Licenčné nastavenia', 
	'LBL_LICENSE_DESC' => 'Spravujte všetky nastavenia týkajúce sa vašej licencie', 
	'LBL_URL' => 'Vaša vtiger URL', 
	'LBL_LICENSE_ACTIVE' => 'Rozšírenie je aktívne', 
	'LBL_LICENSE_INACTIVE' => 'Rozšírenie nie je aktívne', 
	'LBL_INSTALLER_NOT_ACTIVE' => 'Inštalujte alebo aktivujte modul ITS4YouInstaller na správu vašich licencií.', 
	'LBL_INSTALLER_UPDATE' => 'Aktualizujte modul ITS4YouInstaller pre prístup k Mazanie kampaní', 
	'LBL_DOWNLOAD' => 'Stiahnuť', 
	'LBL_DOWNLOAD_INSTALLER' => 'Stiahnuť Installer', 
	'LBL_BLOCK_SYSTEM_INFORMATION' => 'Systémové informácie', 
	'LBL_EDIT_FIELDS' => 'Polia & Rozloženie', 
	'LBL_EDIT_WORKFLOWS' => 'Pracovné postupy', 
	'LBL_MODULE_SEQUENCE_NUMBERING' => 'Číslovanie', 
	'LBL_VERSION' => 'Verzia', 
	'LBL_INTEGRATION' => 'Integrácia', 
	'LBL_MODULE_REQUIREMENTS' => 'Požiadavky modulu', 
	'LBL_LICENSE_MANAGE' => 'Správa licencií', 
);

$jsLanguageStrings = array(
	'JS_ACTION_STATUS_CHANGED' => 'Stav bol úspešne zmenený', 
	'JS_ACTION_DELETED_SUCCESSFULLY' => 'Vzťah bol úspešne odstránený', 
	'JS_GDPR_DELETED_SUCCESSFULLY' => 'Mazanie kampane bolo úspešne odstránené', 
	'LBL_UNINSTALL_CONFIRM' => 'Ste si istí, že chcete úplne odstrániť Mazanie kampane z vášho Vtigera?', 
	'JS_UNINSTALL_CONFIRM' => 'Ste si istý/á, že chcete úplne odstrániť modul z vášho vTiger?', 
); 

