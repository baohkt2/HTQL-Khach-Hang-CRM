<?php
/* *********************************************************************************
 * The content of this file is subject to the ITS4YouClearCampaigns license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ******************************************************************************* */

$languageStrings = array(
	'LBL_LICENSE_USED_BY_OTHER_USERS' => 'Licencia používaná inými používateľmi', 
	'ITS4YouClearCampaigns' => 'Mazanie kampaní', 
	'LBL_DELETE_CONTACTS_CONFIRMATION' => 'Naozaj chcete odstrániť všetky kontakty v tejto kampani?', 
	'LBL_DELETE_LEADS_CONFIRMATION' => 'Naozaj chcete odstrániť všetky potenciálne zákazníky v tejto kampani?', 
	'LBL_DELETE_ACCOUNTS_CONFIRMATION' => 'Naozaj chcete odstrániť všetky organizácie v tejto kampani?', 
	'LBL_DELETE_CONTACTS' => 'Vzťahy kontaktov boli odstránené', 
	'LBL_DELETE_LEADS' => 'Vzťahy potenciálnych zákazníkov boli odstránené', 
	'LBL_DELETE_ACCOUNTS' => 'Vzťahy organizácií boli odstránené', 
	'LBL_NO_CONTACTS' => 'K vybranej kampani nie sú priradené žiadne kontakty', 
	'LBL_NO_LEADS' => 'K vybranej kampani nie sú priradení žiadni potenciálni zákazníci', 
	'LBL_NO_ACCOUNTS' => 'K vybranej kampani nie sú priradené žiadne organizácie', 
	'LBL_DELETE_ERROR' => 'Počas odstraňovania došlo k chybe', 
	'SINGLE_ITS4YouClearCampaigns' => 'Mazanie kampaní', 
	'LBL_MODULE_NAME' => 'Mazanie kampaní', 
	'LBL_UNINSTALL' => 'Odinštalovať', 
	'LBL_UNINSTALL_DESC' => 'Úplne odstrániť modul z vášho Vtigera.', 
	'LBL_MODULE' => 'Modul', 
	'LBL_LICENSE_SETTINGS_INFO' => 'Spravujte svoj licenčný kľúč modulu', 
	'LBL_LICENSE' => 'Licenčné nastavenia', 
	'LBL_LICENSE_DESC' => 'Spravujte všetky nastavenia týkajúce sa vašej licencie', 
	'LBL_URL' => 'Vaša vtiger URL', 
	'LBL_LICENSE_ACTIVE' => 'Rozšírenie je aktívne', 
	'LBL_LICENSE_INACTIVE' => 'Rozšírenie nie je aktívne', 
	'LBL_INSTALLER_NOT_ACTIVE' => 'Inštalujte alebo aktivujte modul ITS4YouInstaller na správu vašich licencií.', 
	'LBL_INSTALLER_UPDATE' => 'Aktualizujte modul ITS4YouInstaller pre prístup k Mazanie kampaní', 
	'LBL_DOWNLOAD' => 'Stiahnuť', 
	'LBL_DOWNLOAD_INSTALLER' => 'Stiahnuť Installer', 
	'COPYRIGHT' => ':: IT-Solutions4You', 
	'LBL_UPGRADE' => 'Aktualizácia', 
	'LBL_BLOCK_SYSTEM_INFORMATION' => 'Systémové informácie', 
	'LBL_EDIT_FIELDS' => 'Polia & Rozloženie', 
	'LBL_EDIT_WORKFLOWS' => 'Pracovné postupy', 
	'LBL_MODULE_SEQUENCE_NUMBERING' => 'Číslovanie', 
	'LBL_VERSION' => 'Verzia', 
	'LBL_INTEGRATION' => 'Integrácia', 
	'LBL_MODULE_REQUIREMENTS' => 'Požiadavky modulu', 
	'LBL_LICENSE_MANAGE' => 'Správa licencií', 
);

$jsLanguageStrings = array(
	'JS_UNINSTALL_CONFIRM' => 'Ste si istý/á, že chcete úplne odstrániť modul z vášho vTiger?', 
); 

