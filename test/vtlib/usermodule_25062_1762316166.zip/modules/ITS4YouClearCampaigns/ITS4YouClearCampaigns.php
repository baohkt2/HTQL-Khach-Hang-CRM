<?php
/*********************************************************************************
 * The content of this file is subject to the Clear Campaigns 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 ********************************************************************************/

require_once 'modules/Webforms/model/WebformsModel.php';
require_once 'include/Webservices/DescribeObject.php';

class ITS4YouClearCampaigns
{
    // Cache to speed up describe information store
    protected static $moduleDescribeCache = array();
    public $customscript;
    public $links;
    public $linkto;
    public $db;
    public $log;

    /**
     * [module, type, label, url, icon, sequence, handlerInfo]
     * @return array
     */
    public $registerCustomLinks = array(
        ['Campaigns', 'HEADERSCRIPT', 'ITS4YouClearCampaignsJS', 'layouts/v7/modules/ITS4YouClearCampaigns/resources/Detail.js'],
        ['Campaigns', 'DETAILVIEW', 'Clear Contact List', 'javascript:ITS4YouClearCampaigns_Detail_Js.ClearCampaign($RECORD$,"Contacts")'],
        ['Campaigns', 'DETAILVIEW', 'Clear Lead List', 'javascript:ITS4YouClearCampaigns_Detail_Js.ClearCampaign($RECORD$,"Leads")'],
        ['Campaigns', 'DETAILVIEW', 'Clear Organization List', 'javascript:ITS4YouClearCampaigns_Detail_Js.ClearCampaign($RECORD$,"Accounts")'],
    );

    public function __construct()
    {
        global $log, $currentModule;

        $this->db = PearDatabase::getInstance();
        $this->log = $log;
    }

    public function vtlib_handler($moduleName, $eventType)
    {
        switch ($eventType) {
            case 'module.postinstall':
            case 'module.enabled':
            case 'module.postupdate':
                $this->addCustomLinks();
                break;
            case 'module.preuninstall':
            case 'module.disabled':
            case 'module.preupdate':
                $this->deleteCustomLinks();
                break;
        }
    }

    public function addCustomLinks()
    {
        $this->updateCustomLinks();
    }

    /**
     * @param bool $register
     */
    public function updateCustomLinks($register = true)
    {
        foreach ($this->registerCustomLinks as $customLink) {
            list($moduleName, $type, $label, $url, $icon, $sequence, $handler) = array_pad($customLink, 7, null);
            $module = Vtiger_Module::getInstance($moduleName);
            $url = str_replace('$LAYOUT$', Vtiger_Viewer::getDefaultLayoutName(), $url);

            if ($module) {
                $module->deleteLink($type, $label);

                if ($register) {
                    $module->addLink($type, $label, $url, $icon, $sequence, $handler);
                }
            }
        }
    }

    public function deleteCustomLinks()
    {
        $this->updateCustomLinks(false);

        $moduleInstance = Vtiger_Module::getInstance('Campaigns');
        $moduleInstance->deleteLink('HEADERSCRIPT', 'ITS4YouClearCampaignsJS');
        $moduleInstance->deleteLink('DETAILVIEWBASIC', 'Clear Contact List');
        $moduleInstance->deleteLink('DETAILVIEWBASIC', 'Clear Lead List');
        $moduleInstance->deleteLink('DETAILVIEWBASIC', 'Clear Organization List');
    }

}