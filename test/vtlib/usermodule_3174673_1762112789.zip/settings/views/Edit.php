<?php
/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Settings_ITS4YouSumAmounts_Edit_View extends Settings_Vtiger_Index_View
{
	/**
	 * @throws AppException
	 */
	public function process(Vtiger_Request $request)
	{
		$qualifiedModule = $request->getModule(false);
		$moduleName = $request->getModule();
		$tabId = $request->get('tab_id');
		$labelRecords = ITS4YouSumAmounts_Label_Model::getLabels($tabId);

		$viewer = $this->getViewer($request);
		$viewer->assign('TAB_ID', $tabId);
		$viewer->assign('LABEL_RECORDS', $labelRecords);
		$viewer->assign('QUALIFIED_MODULE', $qualifiedModule);
		$viewer->assign('MODULE', $moduleName);
		$viewer->assign('TITLE', $moduleName);
		$viewer->assign('BUTTON_LABEL', $moduleName);
		$viewer->view('EditViewContents.tpl', $request->getModule(false));
	}

	/**
	 * @param Vtiger_Request $request
	 * @return array
	 */
	public function getHeaderScripts(Vtiger_Request $request)
	{
		$headerScriptInstances = parent::getHeaderScripts($request);
		$moduleName = $request->getModule();

		$jsFileNames = [
			"modules.Settings.$moduleName.resources.Edit",
		];

		$jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
		$headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);

		return $headerScriptInstances;
	}
}