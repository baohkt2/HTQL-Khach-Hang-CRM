<?php
/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

vimport('~/includes/runtime/Viewer.php');

class Settings_ITS4YouSumAmounts_List_View extends Settings_Vtiger_Index_View
{
    /**
     * @var bool
     */
    protected $isInstalled = false;

    public function __construct()
    {
        parent::__construct();

        $class = explode('_', get_class($this));
        $this->isInstalled = true;
    }

    /**
     * @param Vtiger_Request $request
     * @param bool $display
     */
    public function preProcess(Vtiger_Request $request, $display = true)
    {
        vtws_addDefaultModuleTypeEntity($request->getModule());

        $moduleName = $request->getModule();
        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $settingLinks = array();

        foreach ($moduleModel->getSettingLinks() as $settingsLink) {
            $settingsLink['linklabel'] = sprintf(vtranslate($settingsLink['linklabel'], $moduleName), vtranslate($moduleName, $moduleName));
            $settingLinks['LISTVIEWSETTING'][] = Vtiger_Link_Model::getInstanceFromValues($settingsLink);
        }

        $viewer = $this->getViewer($request);
        $viewer->assign('LISTVIEW_LINKS', $settingLinks);

        parent::preProcess($request, $display);
    }

    /**
     * @param Vtiger_Request $request
     * @throws Exception
     */
    public function process(Vtiger_Request $request)
    {
        if (!$this->isInstalled) {
            (new Settings_ITS4YouInstaller_License_View())->initializeContents($request);
        } else {
            $this->getProcess($request);
        }
    }

    /**
     * @param Vtiger_Request $request
     */
    public function getProcess(Vtiger_Request $request)
    {
        $viewer = $this->getViewer($request);

        $moduleName = $request->getModule(false);
        $entityModules = Vtiger_Module_Model::getEntityModules();
        $searchValue = $request->get('search_value');
        $amountFields = [];

        foreach ($entityModules as $entityModuleId => $entityModule) {
            $moduleInstance = Vtiger_Module::getInstance($entityModuleId);
            $fields = $moduleInstance->getFields();

            foreach ($fields as $fieldName => $fieldModel) {

                if (in_array($fieldModel->get('uitype'), [7, 71, 72])) {
                    $amountFields[$entityModule->getName()][] = $fieldModel;
                }
            }
        }

        if (!empty($searchValue)) {
            $entityModules = Settings_ITS4YouSumAmounts_Module_Model::getListEntriesForSearchValue($entityModules, $searchValue);
        }

        $viewer->assign('searchValue', $searchValue);
        $viewer->assign('displayedAmountFields', ITS4YouSumAmounts_Module_Model::getDisplayedAmountFields());
        $viewer->assign('entityModules', $entityModules);
        $viewer->assign('qualifiedModule', $moduleName);
        $viewer->assign('amountFields', $amountFields);
        $viewer->assign('module', $request->getModule());
        $viewer->assign('version', ITS4YouSumAmounts_Version_Helper::$version);

        $viewer->view('ListViewContents.tpl', $moduleName);
    }

    /**
     * @param Vtiger_Request $request
     * @return mixed|null|string
     */
    function getPageTitle(Vtiger_Request $request)
    {
        $qualifiedModuleName = $request->getModule(false);

        return vtranslate('ITS4YouSumAmounts', $qualifiedModuleName);
    }

    /**
     * @param Vtiger_Request $request
     * @return array
     */
    public function getHeaderScripts(Vtiger_Request $request)
    {
        $headerScriptInstances = parent::getHeaderScripts($request);

        $jsFileNames = [
            '~/libraries/jquery/bootstrapswitch/js/bootstrap-switch.min.js',
            '~layouts/v7/modules/Vtiger/resources/validation.js',
            '~layouts/v7/modules/Settings/Vtiger/resources/List.js',
            '~layouts/v7/modules/Settings/ITS4YouSumAmounts/resources/List.js',
            '~layouts/v7/lib/jquery/Lightweight-jQuery-In-page-Filtering-Plugin-instaFilta/instafilta.js',
            '~layouts/' . Vtiger_Viewer::getDefaultLayoutName() . '/lib/jquery/floatThead/jquery.floatThead.js',
            '~layouts/' . Vtiger_Viewer::getDefaultLayoutName() . '/lib/jquery/perfect-scrollbar/js/perfect-scrollbar.jquery.js',
        ];

        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);

        return $headerScriptInstances;
    }

    /**
     * @param Vtiger_Request $request
     * @return array
     */
    public function getHeaderCss(Vtiger_Request $request)
    {
        $headerCssInstances = parent::getHeaderCss($request);

        $cssFileNames = [
            '~/libraries/jquery/bootstrapswitch/css/bootstrap3/bootstrap-switch.min.css',
            '~layouts/' . Vtiger_Viewer::getDefaultLayoutName() . '/lib/jquery/perfect-scrollbar/css/perfect-scrollbar.css',
        ];

        $cssInstances = $this->checkAndConvertCssStyles($cssFileNames);
        $headerCssInstances = array_merge($headerCssInstances, $cssInstances);

        return $headerCssInstances;
    }
}