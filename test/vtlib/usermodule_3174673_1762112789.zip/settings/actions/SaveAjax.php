<?php
/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Settings_ITS4YouSumAmounts_SaveAjax_Action extends Settings_Vtiger_IndexAjax_View
{
	public function __construct()
	{
		parent::__construct();

		$this->exposeMethod('saveLabel');
		$this->exposeMethod('save');
	}

	/**
	 * @param Vtiger_Request $request
	 * @throws Exception
	 */
	public function process(Vtiger_Request $request)
	{
		$mode = $request->getMode();

		if (!empty($mode) && $this->isMethodExposed($mode)) {
			$this->invokeExposedMethod($mode, $request);
			return;
		}

		$this->save($request);
	}

	public function save(Vtiger_Request $request)
	{
        $moduleId = $request->get('moduleId');

        if ($moduleId) {
            $db = PearDatabase::getInstance();
            $status = $request->get('status');
            $fieldName = $request->get('field');

            if ('off' === $status) {
                $db->pquery('DELETE FROM its4you_soa WHERE moduleId=?', [$moduleId]);
            } else if ('on' === $status) {

                if ($request->get('fieldChanged')) {
                    $db->pquery('UPDATE its4you_soa SET fieldName=? WHERE moduleId=?', [$fieldName, $moduleId]);
                } else {
                    $db->pquery('INSERT INTO its4you_soa VALUES (?, ?)', [$moduleId, $fieldName]);
                }
            }
        }

		$response = new Vtiger_Response();
		$response->setResult(array('success'));
		$response->emit();
	}

	public function saveLabel(Vtiger_Request $request)
	{
		$tabId = $request->get('tab_id');
		$label = decode_html($request->get('label_value'));
		$labelRecord = ITS4YouSumAmounts_Label_Model::getInstanceById($tabId, $label);
		$labelRecord->set('is_active', $request->get('is_active'));
		$labelRecord->set('label_width', $request->get('label_width'));

		$labelMode = $request->get('label_mode');

		if ('Default' === $labelMode) {
			$labelRecord->set('label_mode', null);
			$labelRecord->set('label_config', null);
		} else {
			$labelRecord->set('label_mode', $request->get('label_mode'));
			$labelRecord->setConfig($request->get('label_config'));
		}

		$labelRecord->save();

		$response = new Vtiger_Response();
		$response->setResult(['success' => true]);
		$response->emit();
	}
}
