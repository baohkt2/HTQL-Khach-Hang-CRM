<?php
/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class Settings_ITS4YouSumAmounts_Module_Model extends Settings_Vtiger_Module_Model
{
    /**
     * @param $entityModules
     * @param $searchValue
     * @return array
     */
    public static function getListEntriesForSearchValue($entityModules, $searchValue)
    {
        $filteredEntityModules = [];

        foreach ($entityModules as $entityModuleId => $entityModule) {
            $label = vtranslate($entityModule->get('label'));

            if (false !== strpos(strtolower($label), strtolower($searchValue))) {
                $filteredEntityModules[$entityModuleId] = $entityModule;
            }
        }

        return $filteredEntityModules;
    }
}
