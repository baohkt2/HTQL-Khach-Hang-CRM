<?php
/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class ITS4YouSumAmounts_Basic_Label extends ITS4YouSumAmounts_Label_Model
{
	/**
	 * @return string
	 */
	public function getConfig()
	{
		if ('Checkbox' === $this->get('label_mode')) {
			$config = json_decode($this->get('label_config'), true);

			$this->set('label_config', json_encode([
				['type' => 'checkbox', 'value' => $config[0]['value']],
				['type' => 'textarea', 'value' => $config[1]['value']],
				['type' => 'fields', 'value' => $config[2]['value']],
			], true));

			return json_decode($this->get('label_config'), true);
		}

		return parent::getConfig();
	}
}