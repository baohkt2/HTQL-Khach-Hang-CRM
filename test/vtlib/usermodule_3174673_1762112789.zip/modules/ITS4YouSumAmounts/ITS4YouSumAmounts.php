<?php
/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

require_once 'modules/Webforms/model/WebformsModel.php';
require_once 'include/Webservices/DescribeObject.php';

class ITS4YouSumAmounts
{
	/**
	 * @var string
	 */
	public $LBL_MODULE_NAME = 'Sum of amounts';
	/**
	 * @var PearDatabase
	 */
	/**
	 * @var Logger|MonologLoggerEx|PearDatabase
	 */
	public $db, $log;
	/**
	 * @var array
	 */
	public $list_fields_name = [];
	/**
	 * @var array
	 */
	public $list_fields = [];

    /**
     * [module, type, label, url, icon, sequence, handlerInfo]
     * @return array
     */
    public $registerCustomLinks = array(
        ['ITS4YouSumAmounts', 'HEADERSCRIPT', 'ITS4YouSumAmounts_SumOfAmounts_Js', 'layouts/$LAYOUT$/modules/ITS4YouSumAmounts/resources/SumOfAmounts.js']
    );

	/**
	 *
	 */
	public function __construct()
    {
        global $log;

        $this->db = PearDatabase::getInstance();
        $this->log = $log;
    }

    /**
     * Invoked when special actions are performed on the module.
     *
     * @param $moduleName
     * @param $eventType
     *
     * @throws Exception
     */
    public function vtlib_handler($moduleName, $eventType)
    {
        switch ($eventType) {
            case 'module.postinstall':
            case 'module.postupdate':
            case 'module.enabled':
                $this->addCustomLinks();
                break;
            case 'module.disabled':
            case 'module.preuninstall':
            case 'module.preupdate':
                $this->deleteCustomLinks();
                break;
        }
    }

    /**
     * @throws Exception
     */
    public function addCustomLinks()
    {
		$this->createTables();
        $this->updateCustomLinks();
        $this->updateSettings();
    }

	/**
	 * @return void
	 */
	public function createTables()
	{
		$this->db->pquery('CREATE TABLE IF NOT EXISTS its4you_soa (moduleId INT(10),fieldName VARCHAR(100))');
		$this->db->pquery('CREATE TABLE IF NOT EXISTS its4you_soa_labels (id INT(19) AUTO_INCREMENT, module_id INT(10), is_active INT(1), label_mode VARCHAR(100), label_value VARCHAR(100), label_config TEXT, PRIMARY KEY (id))');
	}

	/**
	 * @return void
	 * @throws Exception
	 */
	public function deleteCustomLinks()
    {
        $this->updateCustomLinks(false);
        $this->updateSettings(false);
    }

    /**
     * @param bool $register
     */
    public function updateCustomLinks($register = true)
    {
        foreach ($this->registerCustomLinks as $customLink) {
            $module = Vtiger_Module::getInstance($customLink[0]);
            $type = $customLink[1];
            $label = $customLink[2];
            $url = str_replace('$LAYOUT$', Vtiger_Viewer::getDefaultLayoutName(), $customLink[3]);

            if ($module) {
                $module->deleteLink($type, $label);

                if ($register) {
                    $module->addLink($type, $label, $url, $customLink[4], $customLink[5], $customLink[6]);
                }
            }
        }
    }

    /**
     * @throws Exception
     */
    public function updateSettings($register = true)
    {
	    if (!$register) {
		    $this->db->pquery('DELETE FROM vtiger_settings_field WHERE name=?', [$this->LBL_MODULE_NAME]);
		    return;
	    }

	    $image = '';
	    $description = 'Create new modules...';
	    $linkTo = 'index.php?module=ITS4YouSumAmounts&parent=Settings&view=List';
	    $result = $this->db->pquery('SELECT 1 FROM vtiger_settings_field WHERE name=?', [$this->LBL_MODULE_NAME]);

	    if ($this->db->num_rows($result)) {
		    $this->db->pquery('UPDATE vtiger_settings_field SET name=?, iconpath=?, description=?, linkto=?, active = ? WHERE name=?', [$this->LBL_MODULE_NAME, $image, $description, $linkTo, '0', $this->LBL_MODULE_NAME]);
	    } elseif (!$this->db->num_rows($result)) {
		    $fieldId = $this->db->getUniqueID('vtiger_settings_field');
		    $blockId = getSettingsBlockId('LBL_OTHER_SETTINGS');

		    $seq_res = $this->db->pquery('SELECT max(sequence) AS max_seq FROM vtiger_settings_field WHERE blockid = ?', [$blockId]);

		    if (0 < $this->db->num_rows($seq_res)) {
			    $cur_seq = $this->db->query_result($seq_res, 0, 'max_seq');

			    if (null !== $cur_seq) {
				    $seq = $cur_seq + 1;
			    }
		    }

		    $this->db->pquery('INSERT INTO vtiger_settings_field(fieldid, blockid, name, iconpath, description, linkto, sequence) VALUES (?,?,?,?,?,?,?)', [$fieldId, $blockId, $this->LBL_MODULE_NAME, $image, $description, $linkTo, $seq]);
	    }

	    $this->db->pquery('UPDATE vtiger_settings_field SET active=0  WHERE name=?', [$this->LBL_MODULE_NAME]);
    }
}
