<?php
/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class ITS4YouSumAmounts_SumOfAmounts_Model extends Vtiger_Base_Model
{
	/**
	 * @var PearDatabase
	 */
	protected $db;
	/**
	 * @var
	 */
	protected $field;
	/**
	 * @var
	 */
	protected $module;
	/**
	 * @var
	 */
	protected $record;

	/**
	 * @param $values
	 */
	public function __construct($values = array())
    {
        parent::__construct($values);

        $this->db = PearDatabase::getInstance();
    }

    /**
     * @throws Exception
     */
    public static function hasPermittedField($module)
    {
        $column = self::getModuleColumn($module);

        if (empty($column)) {
            return false;
        }

        $fields = self::getPermittedFields($module);

        return !empty($fields) && in_array($column, $fields);
    }

    /**
     * @param string $module
     * @return array
     */
    public static function getPermittedFields($module)
    {
        include 'include/utils/ExportUtils.php';

        $adb = PearDatabase::getInstance();
        $query = str_replace('1,2,4,5', '1,2,3,4,5', getPermittedFieldsQuery($module, 'detail_view'));
        $result = $adb->query($query);
        $permittedFields = array();

        while ($row = $adb->fetchByAssoc($result)) {
            array_push($permittedFields, $row['columnname']);
        }

        return $permittedFields;
    }

    /**
     * @param string $module
     * @return string
     * @throws Exception
     */
	public static function getModuleColumn($module)
	{
		$instance = self::getCleanInstance($module);

		return !empty($instance->field->column) ? $instance->field->column : '';
	}

	/**
	 * @throws Exception
	 */
	public static function getCleanInstance($module) {
		$self = new self();
		$self->set('module', $module);
		$self->retrieveData();

		return $self;
	}

    /**
     * @throws Exception
     */
    public static function getInstance($record, $module)
    {
        $self = new self();
        $self->set('record', $record);
        $self->set('module', $module);
        $self->retrieveData();

        return $self;
    }

    /**
     * @throws Exception
     */
    public function retrieveData()
    {
        $result = $this->db->pquery('SELECT * FROM its4you_soa WHERE moduleId=?', [getTabid($this->getModuleName())]);
        $row = $this->db->query_result_rowdata($result);

        foreach ($row as $key => $value) {
            if (!is_numeric($key)) {
                $this->set($key, $value);
            }
        }

        $this->module = Vtiger_Module_Model::getInstance($this->getModuleName());
        $this->field = Vtiger_Field_Model::getInstance($this->getFieldName(), $this->getModule());

		if($this->getRecordId()) {
	        $this->record = Vtiger_Record_Model::getInstanceById($this->getRecordId(), $this->getModule());
		}
    }

	/**
	 * @return Value|null
	 */
	public function getModuleName()
    {
        return $this->get('module');
    }

	/**
	 * @return Value|null
	 */
	public function getRecordId()
    {
        return $this->get('record');
    }

	/**
	 * @return mixed
	 */
	public function getModule()
    {
        return $this->module;
    }

	/**
	 * @return Value|null
	 */
	public function getFieldName()
    {
        return $this->get('fieldname');
    }

	/**
	 * @return mixed
	 */
	public function getField()
    {
        return $this->field;
    }

	/**
	 * @return mixed
	 */
	public function getRecord()
    {
        return $this->record;
    }

	/**
	 * @return array
	 * @throws AppException
	 */
	public function getLabels()
	{
		return ITS4YouSumAmounts_Label_Model::getLabels($this->getModule()->getId());
	}
}