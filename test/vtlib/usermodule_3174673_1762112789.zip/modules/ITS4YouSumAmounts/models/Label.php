<?php
/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

class ITS4YouSumAmounts_Label_Model extends Vtiger_Base_Model
{
	/** @var PearDatabase */
	public $db;
	/** @var bool|Vtiger_Record_Model */
	public $record = false;
	/** @var bool|Vtiger_Module_Model */
	public $module = false;
	/** @var bool|Vtiger_Field_Model */
	public $field = false;

	/**
	 * @throws AppException
	 */
	public static function getLabels($moduleId)
	{
		$instance = self::getInstance($moduleId);
		$field = $instance->getField();
		$labelRecords = [];

		if ($field) {
			$labels = array_keys($field->getPicklistValues());

			foreach ($labels as $label) {
				$label = decode_html($label);
				$labelRecords[$label] = self::getInstanceById($moduleId, $label);
			}
		}

		return $labelRecords;
	}

	/**
	 * @param $moduleId
	 * @return ITS4YouSumAmounts_Basic_Label|mixed
	 */
	public static function getInstance($moduleId)
	{
		$moduleName = getTabModuleName($moduleId);
		$className = 'ITS4YouSumAmounts_' . $moduleName . '_Label';

		if (class_exists($className)) {
			$instance = new $className();
		} else {
			$instance = new ITS4YouSumAmounts_Basic_Label();
		}

		$instance->db = PearDatabase::getInstance();
		$instance->set('module_id', $moduleId);

		return $instance;
	}

	/**
	 * @return bool|Vtiger_Field_Model
	 * @throws AppException
	 */
	public function getField()
	{
		$this->retrieveField();

		if ($this->isEmpty('field_name')) {
			throw new AppException('Missing field name');
		}

		if (!$this->field) {
			$this->field = Vtiger_Field_Model::getInstance($this->get('field_name'), $this->getModule());
		}

		return $this->field;
	}

	/**
	 * @return void
	 * @throws Exception
	 */
	public function retrieveField()
	{
		if (!$this->isEmpty('field_name')) {
			return;
		}

		$adb = PearDatabase::getInstance();
		$result = $adb->pquery('SELECT fieldName FROM its4you_soa WHERE moduleId=?', [$this->get('module_id')]);

		$this->set('field_name', $adb->query_result($result, 0));
	}

	/**
	 * @return bool|Vtiger_Module_Model
	 * @throws AppException
	 */
	public function getModule()
	{
		if ($this->isEmpty('module_id')) {
			throw new AppException('Missing module id');
		}

		if (!$this->module) {
			$this->module = Vtiger_Module_Model::getInstance($this->get('module_id'));
		}

		return $this->module;
	}

	/**
	 * @param $tabId
	 * @param $label
	 * @return self
	 */
	public static function getInstanceById($tabId, $label)
	{
		$instance = self::getInstance($tabId);
		$instance->set('label_value', $label);
		$instance->retrieveData();

		return $instance;
	}

	/**
	 * @return void
	 */
	public function retrieveData()
	{
		$sql = 'SELECT its4you_soa.fieldName as field_name, its4you_soa_labels.* 
			FROM its4you_soa 
    		INNER JOIN its4you_soa_labels ON its4you_soa.moduleId=its4you_soa_labels.module_id 
			WHERE module_id=? AND label_value=?';
		$params = [$this->get('module_id'), $this->get('label_value')];
		$result = $this->db->pquery($sql, $params);
		$row = $this->db->fetchByAssoc($result);

		if (!empty($row['field_name']) && !empty($row['label_value'])) {
			$this->setData(array_merge($this->getData(), $row));
			$this->set('label_config', decode_html($this->get('label_config')));
		}
	}

	/**
	 * @return Value|null
	 */
	public function getValue()
	{
		return $this->get('label_value');
	}

	/**
	 * @return bool
	 */
	public function isActive()
	{
		return !$this->isEmpty('is_active');
	}

	/**
	 * @param $type
	 * @return mixed
	 */
	public function getEditTemplate($type)
	{
		$templateModule = 'Settings:ITS4YouSumAmounts';
		$type = ucfirst($type);

		return vtemplate_path('types/' . $type . '.tpl', $templateModule);
	}

	/**
	 * @param $type
	 * @return mixed
	 */
	public function getModalTemplate($type)
	{
		$templateModule = 'ITS4YouSumAmounts';

		return vtemplate_path('types/' . ucfirst($type) . '.tpl', $templateModule);
	}

	/**
	 * @return array
	 * @throws AppException
	 */
	public function getDynamicFields()
	{
		if (!$this->isDynamicFieldsActive()) {
			return [];
		}

        $result = $this->db->pquery('SELECT dfid, description FROM its4you_dynamicfields WHERE `module`=?', [$this->getModule()->getName()]);
		$values = [];

		while ($row = $this->db->fetchByAssoc($result)) {
			$values[$row['dfid']] = decode_html($row['description']);
		}

		return $values;
	}

	/**
	 * @param $values
	 * @return void
	 */
	public function setConfig($values)
	{
		$configValues = $this->getConfig();

		foreach ($configValues as $configKey => $configValue) {
			$configValues[$configKey]['value'] = $values[$configKey];
		}

		$this->set('label_config', json_encode($configValues, true));
	}

	/**
	 * @return mixed
	 */
	public function getConfig()
	{
		if ($this->isEmpty('label_config')) {
			$this->set('label_config', json_encode([
				['type' => 'textarea'],
				['type' => 'fields'],
				['type' => 'textarea'],
			], true));
		}

		return json_decode($this->get('label_config'), true);
	}

	/**
	 * @return void
	 */
	public function save()
	{
		$params = [
			'module_id' => $this->get('module_id'),
			'is_active' => $this->get('is_active'),
			'label_mode' => $this->get('label_mode'),
			'label_value' => $this->get('label_value'),
			'label_config' => $this->get('label_config'),
		];

		if ($this->isEmpty('id')) {
			$sql = sprintf('INSERT INTO its4you_soa_labels (%s) VALUES (%s)', implode(',', array_keys($params)), generateQuestionMarks($params));
		} else {
			$sql = sprintf('UPDATE its4you_soa_labels SET %s=? WHERE id=?', implode('=?,', array_keys($params)));
			$params['id'] = $this->get('id');
		}

		$this->db->pquery($sql, $params);
	}

	/**
	 * @throws AppException
	 */
	public function getModalTitle()
	{
		$hsbModuleName = 'ITS4YouSumAmounts';

		if ($this->isEmptyConfig()) {
			return vtranslate('LBL_CONFIRM', $hsbModuleName);
		}

		return $this->getModalQuestion();
	}

    /**
     * @return string
     * @throws AppException
     */
    public function getModalQuestion()
	{
		$hsbModuleName = 'ITS4YouSumAmounts';
		$field = $this->getField();
		$fieldModuleName = $this->getModule()->getName();
		$fieldLabel = vtranslate($field->get('label'), $fieldModuleName);
		$fieldValueLabel = vtranslate($this->get('label_value'), $fieldModuleName);

		return sprintf(
			'%s %s %s %s?',
			vtranslate('LBL_CHANGE_STATUS_QUESTION', $hsbModuleName),
			$fieldLabel,
			strtolower(vtranslate('LBL_TO', $hsbModuleName)),
			$fieldValueLabel
		);
	}

    /**
     * @return bool
     */
    public function isEmptyConfig()
	{
		foreach ($this->getConfig() as $config) {
			if (!empty($config['value'])) {
				return false;
			}
		}

		return true;
	}

    /**
     * @return bool
     */
    public function isDynamicFieldsActive()
	{
		return getTabid('ITS4YouDynamicFields') && vtlib_isModuleActive('ITS4YouDynamicFields');
	}

	/**
	 * @param $id
	 * @return array
	 * @throws AppException
	 */
	public function getAllowedFields($id)
	{
		if (!$this->isDynamicFieldsActive()) {
			return [];
		}

		$fields = [];
		$result = $this->db->pquery('SELECT fieldname,mandatory FROM its4you_dynamicfields_fields WHERE dfid=? AND visible=?', [$id, 1]);
		$module = $this->getModule();

		while ($row = $this->db->fetchByAssoc($result)) {
			$fieldName = $row['fieldname'];
			$fieldModel = $this->getAllowedField($fieldName, $row['mandatory']);

			if ($fieldModel) {
				$fields[$fieldName] = $fieldModel;
			}
		}

		$result = $this->db->pquery('SELECT block FROM its4you_dynamicfields_blocks WHERE dfid=? AND visible=?', [$id, 1]);

		while ($row = $this->db->fetchByAssoc($result)) {
			$blockModel = Vtiger_Block_Model::getInstance($row['block'], $module);

			if (!$blockModel) {
				continue;
			}

			foreach ($blockModel->getFields() as $field) {
				$fieldName = $field->get('name');

				if (!empty($fields[$fieldName])) {
					continue;
				}

				$fieldModel = $this->getAllowedField($fieldName);

				if ($fieldModel) {
					$fields[$fieldName] = $fieldModel;
				}
			}
		}

		return $fields;
	}

	/**
	 * @param $fieldName
	 * @param $mandatory
	 * @return Vtiger_Field_Model|null
	 * @throws AppException
	 */
	public function getAllowedField($fieldName, $mandatory = 0)
	{
		$moduleModel = $this->getModule();
		$recordModel = $this->getRecord();
		$fieldModel = Vtiger_Field_Model::getInstance($fieldName, $moduleModel);

		if ($fieldName === $this->getField()->get('name')) {
			return null;
		}

		if ($fieldModel && $fieldModel->isEditable()) {
			if (1 === (int)$mandatory) {
				$fieldModel->set('typeofdata', str_replace('~O', '~M', $fieldModel->get('typeofdata')));
			}

			if ($recordModel) {
				$fieldModel->set('fieldvalue', $recordModel->get($fieldName));
			}

			return $fieldModel;
		}

		return null;
	}

	/**
	 * @return bool|Vtiger_Record_Model
	 */
	public function getRecord()
	{
		return $this->record;
	}

	/**
	 * @param $value
	 * @return void
	 */
	public function setRecord($value)
	{
		$this->record = $value;
	}
}
