/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

Settings_Vtiger_List_Js("Settings_ITS4YouSumAmounts_List_Js", {}, {

    registerEventForShowFields: function () {
        const container = jQuery('.list-content-modules-fields');

        container.on('switchChange.bootstrapSwitch', "input[name='moduleFieldStatus']", function (e) {
            let currentElement = jQuery(e.currentTarget);

            if ('on' === currentElement.val()) {
                currentElement.attr('value', 'off');
            } else {
                currentElement.attr('value', 'on');
            }

            let params = {
                module: app.getModuleName(),
                parent: app.getParentModuleName(),
                'action': 'SaveAjax',
                'moduleId': currentElement.data('id'),
                'status': currentElement.val(),
                'field': currentElement.closest('tr').find('.fieldSelect').find('option:selected').data('value')
            };

            app.request.post({data: params}).then(function (error, data) {

                if (data) {

                    if ('on' === currentElement.val()) {
                        app.helper.showSuccessNotification({
                            message: app.vtranslate('AmountFieldDisplayed')
                        });
                    } else {
                        app.helper.showSuccessNotification({
                            message: app.vtranslate('AmountFieldHidden')
                        });
                    }
                }
            });
        });

        container.on('change', '.fieldSelect', function (e) {
            let currentElement = jQuery(e.currentTarget);
            let status = currentElement.closest('tr').find("input[name='moduleFieldStatus']").val();

            let params = {
                module: app.getModuleName(),
                parent: app.getParentModuleName(),
                'action': 'SaveAjax',
                'moduleId': currentElement.data('module'),
                'field': currentElement.find('option:selected').data('value'),
                'status': status,
                'fieldChanged': true
            };

            app.request.post({data: params}).then(function (error, data) {

                if (data) {

                    if ('on' === status) {
                        app.helper.showSuccessNotification({
                            message: app.vtranslate('AmountFieldSaved')
                        });
                    } else {
                        app.helper.showErrorNotification({
                            message: app.vtranslate('DisplayFieldsForModule')
                        });
                    }
                }
            });
        });
    },

    registerSearch: function () {
        const thisInstance = this;
        const container = jQuery('.list-content-modules-fields');

        container.on('keyup', '.searchModules', function (e) {
            if (13 === e.which) {
                thisInstance.loadListViewRecords();
            }
        });
    },

    loadListViewRecords: function () {
        let aDeferred = jQuery.Deferred(),
            params = {
                'module': app.getModuleName(),
                'parent': app.getParentModuleName(),
                'view': 'List',
                'search_value': jQuery('.searchModules').val(),
            };

        app.helper.showProgress();
        app.request.pjax({data: params}).then(function (err, res) {

            let html = $(res).find('.list-content-modules-fields').html(),
                container = jQuery('.list-content-modules-fields');
            container.html(html);

            app.helper.hideProgress();
            jQuery("input[name='moduleFieldStatus']").bootstrapSwitch();
            jQuery('.list-content-modules-fields .select2').select2();
            aDeferred.resolve(res);
        });

        return aDeferred.promise();
    },

    registerEvents: function () {
        jQuery("input[name='moduleFieldStatus']").bootstrapSwitch();
        this.registerEventForShowFields();
        this.registerSearch();
    }
});