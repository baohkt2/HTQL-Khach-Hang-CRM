/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

Settings_Vtiger_Index_Js("Settings_ITS4YouSumAmounts_Edit_Js", {}, {
    registerEvents() {
        this.registerAppTriggerEvent();
        this.registerToggleBody();
        this.registerFormSave();
    },
    registerToggleBody() {
        const self = this;

        self.getContainer().on('click', '.labelToggle', function() {
            let labelBody = $(this).parents('.labelForm').find('.labelBody'),
                isVisible = labelBody.is(':visible');

            $('.labelBody').addClass('hide');

            if(!isVisible) {
                labelBody.removeClass('hide');
            }
        });
    },
    registerFormSave() {
        const self = this;

        self.getContainer().on('submit', '.labelForm', function (e) {
            e.preventDefault();

            let data = $(this).serialize();

            app.request.post({data: data}).then(function (error, data) {
                if (!error) {
                    app.helper.showSuccessNotification({message: app.vtranslate('JS_SUCCESS_SAVE_LABEL')})
                }
            })
        })
    },
    getContainer() {
        return $('.labelsHeaderStatusBarContainer')
    },
})