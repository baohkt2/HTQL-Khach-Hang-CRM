/* * *******************************************************************************
 * The content of this file is subject to the ITS4YouSumAmounts license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

/** @var ITS4YouSumAmounts_SumOfAmounts_Js */
Vtiger.Class('ITS4YouSumAmounts_SumOfAmounts_Js', {
    afterSaveReload: true,
    instance: false,
    getInstance: function () {
        if (!this.instance) {
            this.instance = new ITS4YouSumAmounts_SumOfAmounts_Js();
        }

        return this.instance;
    },

}, {
    getDetailViewContainer: function () {
        return jQuery('.detailViewContainer');
    },

    addTotalSummary: function () {
        let self = this,
            listInstance = Vtiger_List_Js.getInstance(),
            defParams = listInstance.getDefaultParams(),
            urlParams = {};

        if (typeof urlParams.search_params == "undefined") {
            urlParams.search_params = JSON.stringify(listInstance.getListSearchParams(false));
        }
        urlParams = jQuery.extend(defParams, urlParams);

        let params = {
                module: 'ITS4YouSumAmounts',
                view: 'SumOfAmounts',
                sourceModule: app.getModuleName(),
                listParams: urlParams,
            };

        app.request.post({data: params}).then(function (error, data) {
            if (!error && data !== '') {
                if (data !== 'ITS4YouSumOfAmount: Empty sum fields') {
                    jQuery('.SumOfAmounts').remove();
                    let $actions = jQuery('.listview-actions-container .row');

                    let $cols = $actions.children('div');

                    if ($cols.length === 3) {
                        $cols.eq(1).removeClass('col-md-6').addClass('col-md-4');
                        $cols.eq(0).removeClass('col-md-3').addClass('col-md-5');

                        let badge = `<div class="SumOfAmounts btn-group paddingLeft5px" style="display: inline-block; align-items: center;">` + data + `</div>`;

                        $cols.eq(0).append(badge);
                    }
                } else {
                    console.log(data);
                }
            }
        });
    },

    addTotalSummaryClick: function () {
        const self = this;

        $('.listview-actions-container').on('click', '.SumOfAmounts', function (e) {
            self.addTotalSummary();
        });
    },

    registerPostListViewFilterClick: function () {
        const self = this;

        app.event.on('post.listViewFilter.click', function (event, searchRow) {
            self.addTotalSummary();
        });
    },

    getActiveTabName: function () {
        const self = this;
        let activeTabItem = jQuery('.related-tabs', self.getDetailViewContainer()).find('li.tab-item').filter('.active');

        if (!activeTabItem.length) {
            activeTabItem = jQuery('.related-tabs', self.getDetailViewContainer()).find('li.tab-item:first');
        }

        return activeTabItem.data('module');
    },

    addTotalSummaryRelated: function () {
        const self = this;
        let relatedModuleName = self.getActiveTabName();

        if ('' === relatedModuleName) {
            return false;
        }

        let tabElement = jQuery('div.related-tabs').find('li.active'),
            relInstance = Vtiger_RelatedList_Js.getInstance(app.getRecordId(), app.getModuleName(), tabElement, relatedModuleName),
            urlParams = {};

        if (typeof urlParams.search_params == "undefined") {
            urlParams.search_params = JSON.stringify(relInstance.getCompleteParams({}));
        }

        let params = {
            module: 'ITS4YouSumAmounts',
            view: 'SumOfAmounts',
            mode: 'SumOfAmountsRelation',
            sourceModule: app.getModuleName(),
            listParams: urlParams,
        };

        app.request.post({data: params}).then(function (error, data) {
            if (!error && data !== '') {
                if (data !== 'ITS4YouSumOfAmount: Empty sum fields') {
                    jQuery('.SumOfAmounts').remove();
                    let $actions = jQuery('.relatedHeader .row');
                    let $cols = $actions.children('div');
                    let badge = `<div class="SumOfAmounts btn-group paddingLeft5px"  style="display: flex; align-items: center; height: 30px;" >` + data + `</div>`;

                    jQuery('.btn-toolbar').contents().filter(function() {
                        return this.nodeType === 3 && this.nodeValue === '\u00a0'; // &nbsp;
                    }).remove();

                    $cols.eq(0).append(badge);
                } else {
                    console.log(data);
                }
            }
        });
    },

    addTotalSummaryRelatedClick: function () {
        const self = this;

        app.event.on('post.relatedListLoad.click', function (event, parentRecordId, params) {
            self.addTotalSummaryRelated();
        });
    },

    registerEvents: function () {
        if ('List' === app.getViewName()) {
            this.addTotalSummary();
            this.addTotalSummaryClick();
            this.registerPostListViewFilterClick();
        }

        if ('Detail' === app.getViewName()) {
            this.addTotalSummaryRelated();
            this.addTotalSummaryRelatedClick();
        }
    },

});

jQuery(document).ready(function () {
    ITS4YouSumAmounts_SumOfAmounts_Js.getInstance().registerEvents();
});
