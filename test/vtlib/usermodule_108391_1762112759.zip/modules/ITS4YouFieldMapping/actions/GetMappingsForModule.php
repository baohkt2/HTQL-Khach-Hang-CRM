<?php
/*********************************************************************************
 * The content of this file is subject to the FieldMapping 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * *******************************************************************************/

class ITS4YouFieldMapping_GetMappingsForModule_Action extends Vtiger_Action_Controller
{
    /**
     * @param Vtiger_Request $request
     * @return void
     */
    public function checkPermission(Vtiger_Request $request)
    {
    }

    /**
     * @param Vtiger_Request $request
     */
    public function process(Vtiger_Request $request)
    {
        $response = new Vtiger_Response();
        $response->setResult(array(
            'mappingId' => ITS4YouFieldMapping_Util_Helper::getMappingIdFromField($request->get('forField'), $request->get('forModule')),
        ));
        $response->emit();
    }
}
